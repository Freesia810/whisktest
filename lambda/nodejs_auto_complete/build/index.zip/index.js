function main(params) {
	return (require('./handler'))(params, null)
}

exports.main = main
